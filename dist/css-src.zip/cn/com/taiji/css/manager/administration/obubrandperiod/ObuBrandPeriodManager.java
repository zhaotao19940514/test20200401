package cn.com.taiji.css.manager.administration.obubrandperiod;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.css.entity.ObuBrandPeriodVehicle;
import cn.com.taiji.css.model.administration.obubrandperiod.ObuBrandPeriodResponse;

public interface ObuBrandPeriodManager {
	//查询一个时间段内每个渠道的开签数据明细
	public File queryByDate(String startDate,String endDate) throws ManagerException;
	
	ObuBrandPeriodResponse importExcel(List<ObuBrandPeriodVehicle> zklVehicle) throws ManagerException;
	
	public List<ObuBrandPeriodVehicle> getLines(File importFile) throws IOException;
	
	public  ObuBrandPeriodResponse saveFile(MultipartFile file) throws ManagerException;
	
	public File getExcelFilePath(HttpServletRequest request) throws ManagerException;
}
