package cn.com.taiji.css.manager.administration.obubrandperiod;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.common.manager.pub.FileHelper;
import cn.com.taiji.common.model.pub.PoiExcelInfo;
import cn.com.taiji.css.entity.ObuBrandPeriodVehicle;
import cn.com.taiji.css.manager.abstractmanager.AbstractDsiCommManager;
import cn.com.taiji.css.manager.util.CssUtil;
import cn.com.taiji.css.model.MyFinals;
import cn.com.taiji.css.model.administration.obubrandperiod.ObuBrandPeriodResponse;
import cn.com.taiji.css.repo.jpa.ObuBrandPeriodVehicleRepo;
import cn.com.taiji.qtk.entity.dict.ObuStatus;
@Service
public class ObuBrandPeriodManagerImpl extends AbstractDsiCommManager implements ObuBrandPeriodManager{

	@Autowired
	private ObuBrandPeriodVehicleRepo zklVehicleRepo;
	
	/**
	 * 获取行数据
	 * @throws IOException 
	 * 
	 */
	public List<ObuBrandPeriodVehicle> getLines(File importFile) throws IOException
	{
		PoiExcelInfo info = new PoiExcelInfo();
		info.setColSize(1);//总数据列数
		info.setExcelInput(new FileInputStream(importFile));
		info.setSheetIndex(0);
		info.setFromRow(1);
		info.setToRow(-1);
		info.setBreakOnRowNull(true);
		info.setXlsx(true);
		Workbook workbook = createWorkbook(info.getExcelInput(), info.isXlsx());
		List<ObuBrandPeriodVehicle> rs = new ArrayList<ObuBrandPeriodVehicle>();
		Sheet sheet = workbook.getSheetAt(info.getSheetIndex()); 
		if (sheet == null) return rs;
		int fromRow = info.getFromRow() < 0 ? 0 : info.getFromRow();
		int toRow = info.getToRow() < 0 ? Integer.MAX_VALUE : info.getToRow();
		if (toRow < fromRow) throw new IllegalArgumentException("结束行号不能小于开始行号.");
		String batchId=LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS"))+CssUtil.getRandomString(5);
		for (int i = 0; i <= toRow; i++)
		{
			System.out.println("----------------------正在执行第:"+i);
			if (i < fromRow) continue;
			Row row = sheet.getRow(i);
			if (info.isBreakOnRowNull() && row == null) break;
			if (row == null) continue;// 空行不退出时，忽略空行
			Map<Integer, Cell> rowData = new HashMap<Integer, Cell>();
			for (int j = 0; j < info.getColSize(); j++)
			{
				Cell cell = row.getCell(j);
				// 为空时，new一个空cell
				rowData.put(j, cell == null ? getCell(sheet, i, j) : cell);
			}
			ObuBrandPeriodVehicle e = row2Model(i, rowData,batchId);
			if (e != null) rs.add(e);
		}
		return rs;
	}
	
	
	public  ObuBrandPeriodResponse saveFile(MultipartFile file) throws ManagerException {
		ObuBrandPeriodResponse response =new ObuBrandPeriodResponse();
		String parentDirRelativePath = MyFinals.OBUBRANDPERIOD;
		String fileAbsolutePath = savePic(file, parentDirRelativePath);
		String fileName=file.getOriginalFilename();
		response.setFilePath(fileAbsolutePath);
		response.setFileName(fileName);
		return response;
}
	
	private static String savePic(MultipartFile file,String parentDir) throws ManagerException{
		String destDirPath = FileHelper.getDataPath().concat(File.separator).concat(parentDir).concat(File.separator);
		File destDir = new File(destDirPath);
		if(!destDir.exists()){destDir.mkdirs();}
		String destFilePath = destDirPath+generateFileName(file.getOriginalFilename());
		File destFile = new File(destFilePath);
		saveFile(file,destFile);
		return destDirPath;
//		return getFilePathlWithOutRoot(destDirPath);
	}
	
	
	public static String generateFileName(String suffix) {
		return suffix;
	}
	public static String getSuffix(String fileName){
		return fileName.substring(fileName.lastIndexOf("."));
	}
	public static String generateFileName(MultipartFile file){
		return getSuffix(file.getOriginalFilename());
	}
	
	private static Workbook createWorkbook(InputStream in, boolean xlsx) throws IOException
	{
		return xlsx ? new XSSFWorkbook(in) : new HSSFWorkbook(new POIFSFileSystem(in));
	}
	
	/**
	 * 获取指定单元格，存在返回值，不存在新建单元格
	 * 
	 * @param sheet
	 *            sheet页
	 * @param row
	 *            行号
	 * @param col
	 *            列号
	 * @return 单元格
	 */
	public static Cell getCell(Sheet sheet, int row, int col)
	{
		Row sheetRow = sheet.getRow(row);
		if (sheetRow == null) sheetRow = sheet.createRow(row);
		Cell cell = sheetRow.getCell(col);
		if (cell == null) cell = sheetRow.createCell(col);
		return cell;
	}
	/**
	 * 
	 * @param file
	 * @param destFile
	 * @throws ManagerException
	 */
	private static void saveFile(MultipartFile file,File destFile) throws ManagerException{
		OutputStream out = null;
		try {
			out = new FileOutputStream(destFile);
			out.write(file.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
			throw new ManagerException("文件存储失败");
		}
		 finally{
			if(out!=null){
				try {
					out.close();
				} catch (IOException e) {
					e.printStackTrace();
					throw new ManagerException("文件流关闭失败");
				}
			}
		}
	}
	
	public ObuBrandPeriodVehicle row2Model(int row, Map<Integer, Cell> rowData,String batchId)
	{
		try {
//		String intRand=RechargeIdUniqueNo.getSerialNo();
//		String orderId=new SimpleDateFormat("yyyyMMddHHmmss").format(new Date())+CssUtil.getRandomString(5);

		if (row == 0) return null;
		if (rowData.size() != 1)
		{
			logger.info(row + "行数据不完整");
			return null;
		}
		rowData.get(0).setCellType(CellType.STRING);//  车辆ID

		String vehicleID;
		vehicleID = rowData.get(0).getStringCellValue().trim();
		

		ObuBrandPeriodVehicle info = new ObuBrandPeriodVehicle();
		info.setVehicleId(vehicleID);
		return info;
		} catch (NumberFormatException e) {
			e.printStackTrace();
			System.out.println("数据转换异常：--------------------------数据源为"+rowData);
		}
		return null;
	}
	
	
	// 插入数据
	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ObuBrandPeriodResponse importExcel(List<ObuBrandPeriodVehicle> requset) throws ManagerException {
		ObuBrandPeriodResponse rsp=new ObuBrandPeriodResponse();
		List<ObuBrandPeriodVehicle> status=new ArrayList<ObuBrandPeriodVehicle>();
		int i =0;
		for(ObuBrandPeriodVehicle u: requset) {
			i++;
			System.out.println("共"+requset.size()+"条，现已校验到第"+i);
			rsp=u.validate();
			if(u.getVehicleId()!=null) {
				status.add(u);
				rsp.setMessage("数据导入成功！车牌ID："+u.getVehicleId());
				rsp.setStatus(1);
			}else {
				rsp.setMessage("数据导入失敗！车牌不能为空");
				rsp.setStatus(-1);
			}
		}
		System.out.println("删除历史数据。。。。。");
		zklVehicleRepo.deleteAll();
		System.out.println("保存新数据。。。。。");
		zklVehicleRepo.saveAll(status);
		return rsp;
	}

	public File getExcelFilePath(HttpServletRequest request) throws ManagerException {
	    File file = new File("/home/filedata/OBUBrandPeriodExport/"+"车牌查询开签明细"+".xls");
	    if(!file.getParentFile().exists()) {
	    	file.getParentFile().mkdirs();
	    }
	    if(file.exists()) {
	    	//文件存在
	    	file.delete();
	    }
		List<Object[]> list =  zklVehicleRepo.findByVehicle();
        // 创建excel
        HSSFWorkbook wk = new HSSFWorkbook();
        // 创建一张工作表
        HSSFSheet sheet = wk.createSheet();
        // 2
        sheet.setDefaultColumnWidth(20);
        sheet.setDefaultRowHeightInPoints(20*100);
        HSSFRow row = sheet.createRow(0);
        // 创建第一行的第一个单元格
        // 想单元格写值
        HSSFCell cell = row.createCell((short) 0);
        cell.setCellValue("序号");
        cell = row.createCell((short)1);
        cell.setCellValue("车牌ID");
        cell = row.createCell((short)2);
        cell.setCellValue("OBU号");
        cell = row.createCell((short)3);
        cell.setCellValue("OBU状态");
        cell = row.createCell((short)4);
        cell.setCellValue("OBU状态更新时间");
        cell = row.createCell((short)5);
        cell.setCellValue("OBU渠道名称 ");
        cell = row.createCell((short)6);
        cell.setCellValue("OBU厂家");
        // 创建第一行
        for (short i=0;i<list.size();i++)
        {
            row = sheet.createRow(i+1);
            row.createCell(0).setCellValue(i+1);
            row.createCell(1).setCellValue((String)list.get(i)[0]);
            row.createCell(2).setCellValue((String)list.get(i)[1]);
            row.createCell(3).setCellValue(ObuStatus.fromCode(((BigDecimal)list.get(i)[2]).intValue()).getValue());
            row.createCell(4).setCellValue((String)list.get(i)[3]);
            row.createCell(5).setCellValue((String)list.get(i)[4]);
            row.createCell(6).setCellValue((String)list.get(i)[5]);
        }
       try {
           wk.write(new FileOutputStream(file));
           wk.close();
	} catch (IOException e) {
		e.printStackTrace();
		throw new ManagerException("关闭流出错,请联系管理员");
	}
       return file;
	}


	@Override
	public File queryByDate(String startDate, String endDate) throws ManagerException {
		 File file = new File("/home/filedata/OBUBrandPeriodExport/"+"时间统计开签明细"+".xls");
		    if(!file.getParentFile().exists()) {
		    	file.getParentFile().mkdirs();
		    }
		    if(file.exists()) {
		    	//文件存在
		    	file.delete();
		    }
		    DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		    LocalDateTime start = LocalDateTime.parse(startDate,df);
		    LocalDateTime end = LocalDateTime.parse(endDate,df);
			List<Object[]> list =  zklVehicleRepo.queryByTime(start,end);
	        // 创建excel
	        HSSFWorkbook wk = new HSSFWorkbook();
	        // 创建一张工作表
	        HSSFSheet sheet = wk.createSheet();
	        // 2
	        sheet.setDefaultColumnWidth(20);
	        sheet.setDefaultRowHeightInPoints(20*100);
	        HSSFRow row = sheet.createRow(0);
	        // 创建第一行的第一个单元格
	        // 想单元格写值
	        HSSFCell cell = row.createCell((short) 0);
	        cell.setCellValue("序号");
	        cell = row.createCell((short)1);
	        cell.setCellValue("渠道名称");
	        cell = row.createCell((short)2);
	        cell.setCellValue("厂家");
	        cell = row.createCell((short)3);
	        cell.setCellValue("开签数量");
	        cell = row.createCell((short)4);
	        // 创建第一行
	        for (short i=0;i<list.size();i++)
	        {
	            row = sheet.createRow(i+1);
	            row.createCell(0).setCellValue(i+1);
	            row.createCell(1).setCellValue((String)list.get(i)[0]);
	            row.createCell(2).setCellValue((String)list.get(i)[1]);
	            row.createCell(3).setCellValue(list.get(i)[2].toString());
	        }
	       try {
	           wk.write(new FileOutputStream(file));
	           wk.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new ManagerException("关闭流出错,请联系管理员");
		}
	       return file;
	}

}
