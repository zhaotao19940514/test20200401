package cn.com.taiji.css.manager.administration.section4x.operationlog;

import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.css.model.administration.section4x.Operation4xLogRequest;

public interface Operation4xLogManager {

	public Pagination getLog(Operation4xLogRequest queryModel);
}
