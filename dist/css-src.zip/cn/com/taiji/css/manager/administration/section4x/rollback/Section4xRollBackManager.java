package cn.com.taiji.css.manager.administration.section4x.rollback;

import cn.com.taiji.common.manager.ManagerException;

public interface Section4xRollBackManager {

	/**
	 * 
	 * @param batchNo 操作表中的操作批次号
	 * @param rollBackType 回滚类型 2：卡回滚  1：obu回滚
	 * @throws ManagerException
	 */
	public void doRollBack(String batchNo,Integer rollBackType, String staffId) throws ManagerException;
}
