package cn.com.taiji.css.manager.apply.baseinfo;

import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.css.model.apply.customermanager.AccountManagementRequest;

public interface AccountManagementManager {
	Pagination queryPage(AccountManagementRequest queryModel);
}
