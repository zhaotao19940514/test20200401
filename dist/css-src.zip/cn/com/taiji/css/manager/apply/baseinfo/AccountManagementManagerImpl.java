package cn.com.taiji.css.manager.apply.baseinfo;

import org.springframework.stereotype.Service;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.css.model.apply.customermanager.AccountManagementRequest;
@Service
public class AccountManagementManagerImpl extends AbstractManager implements AccountManagementManager{

	@Override
	public Pagination queryPage(AccountManagementRequest queryModel) {
		// TODO Auto-generated method stub
		return null;
	}

}
