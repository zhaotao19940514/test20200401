/**
 * @Title RechargeDetailManager.java
 * @Package cn.com.taiji.css.manager.apply.baseinfo
 * @Description TODO
 * @author yaonanlin
 * @date 2018年8月21日 下午12:35:19
 * @version V1.0
 */
package cn.com.taiji.css.manager.apply.baseinfo;

import cn.com.taiji.qtk.entity.ChargeDetail;

/**
 * @ClassName RechargeDetailManager
 * @Description TODO
 * @author yaonl
 * @date 2018年08月21日 12:35:19
 * @E_mail yaonanlin@163.com
 */
public interface ChargeDetailManager {
	ChargeDetail findByChargeDetailId(String chargeDetailId);
}

