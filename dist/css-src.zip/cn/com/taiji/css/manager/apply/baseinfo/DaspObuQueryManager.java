package cn.com.taiji.css.manager.apply.baseinfo;

import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.css.entity.User;
import cn.com.taiji.css.model.customerservice.cardobuquery.DaspObuQueryRequest;
import cn.com.taiji.dsi.model.comm.protocol.inquire.DaspObuInfoQueryCommResponse;
import cn.com.taiji.qtk.entity.OBUInfo;

public interface DaspObuQueryManager {


	DaspObuInfoQueryCommResponse findByObuIdInDasp(DaspObuQueryRequest queryModel, User user) throws ManagerException;

	OBUInfo findByObuIdInDsi(DaspObuQueryRequest queryModel);

}
