package cn.com.taiji.css.manager.apply.quickapply;

import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.css.model.qtzt.request.IssueOrderRequestData;
import cn.com.taiji.css.model.qtzt.response.IssueOrderResponseData;

public interface BatchIssueManager {
	/**
	 * 批量发行（批量生成发行订单）
	 */
	public void batchIssue();
	
	public IssueOrderResponseData issueOrder(IssueOrderRequestData reqData) throws ManagerException;
}
