package cn.com.taiji.css.manager.apply.quickapply;

import java.util.List;

import cn.com.taiji.css.entity.YangCheng;

public interface BatchOpenCardObuManager {
	
	/**
	 * 批量发行（批量生成发行订单）
	 */
	public void batchOpen();
	
}
