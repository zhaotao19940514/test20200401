package cn.com.taiji.css.manager.apply.quickapply;

import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.css.model.apply.quickapply.CardRechargeRequest;

public interface CardRechargeManager {
	Pagination queryPage(CardRechargeRequest queryModel);
}
