package cn.com.taiji.css.manager.apply.quickapply;

public interface DeviceCheckManager {
	
}
