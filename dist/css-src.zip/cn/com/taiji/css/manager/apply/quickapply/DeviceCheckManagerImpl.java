package cn.com.taiji.css.manager.apply.quickapply;

import org.springframework.stereotype.Service;

import cn.com.taiji.common.manager.AbstractManager;
@Service
public class DeviceCheckManagerImpl extends AbstractManager  implements DeviceCheckManager{

}
