/**
 * @Title RechargeManager.java
 * @Package cn.com.taiji.css.manager.customerservice.finance
 * @Description TODO
 * @author yaonanlin
 * @date 2018年6月25日 下午5:16:25
 * @version V1.0
 */
package cn.com.taiji.css.manager.customerservice.card;

import java.io.File;
import java.util.List;

import cn.com.taiji.qtk.entity.LkfInConsumeDetailsOl;

/**
 * @ClassName CancelManager.java
 * @author zhaotao
 * @Description 
 * @date2018年12月24日
 */
public interface StorageImportManager {

	List<LkfInConsumeDetailsOl> getLines(File file) throws Exception;
}

