package cn.com.taiji.css.manager.customerservice.finance;

import cn.com.taiji.css.model.appajax.AppAjaxResponse;

public class CardChargeResponse extends AppAjaxResponse {

}
