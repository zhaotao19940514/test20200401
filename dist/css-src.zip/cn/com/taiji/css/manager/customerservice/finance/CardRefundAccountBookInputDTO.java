package cn.com.taiji.css.manager.customerservice.finance;

import java.io.Serializable;

import com.alibaba.excel.annotation.ExcelProperty;

@SuppressWarnings("serial")
public class CardRefundAccountBookInputDTO  implements Serializable{

	@ExcelProperty(index = 0)
	private String sortNo;//编号
	
	@ExcelProperty(index = 1)
	private String serialNo;//OA号

	@ExcelProperty(index = 2)
	private String phone;//电话
	
	@ExcelProperty(index = 3)
	private String bankCardNo;//银行卡号
	
	@ExcelProperty(index = 4)
	private String userName;//用户名
	
	@ExcelProperty(index = 5)
	private String openBankProvince;//开户行所在省
	
	@ExcelProperty(index = 6)
	private String openBankCity;//开户行所在市
	
	@ExcelProperty(index = 7)
	private String bankName;//银行名
	
	@ExcelProperty(index = 8)
	private String branchName;//支行名称
	
	@ExcelProperty(index = 9)
	private Double refundAmount;//退费额金额
	
	@ExcelProperty(index = 10)
	private String cardId;//ETC卡号
	
	@ExcelProperty(index = 11)
	private String vehiclePate;//车牌号
	
	@ExcelProperty(index = 12)
	private String remark;//备注
	
	@ExcelProperty(index = 13)
	private String refundStatus;//退费状态
	
	@ExcelProperty(index = 14)
	private String refundFailReason;//退费失败原因
	
	@ExcelProperty(index = 15)
	private String submiteTime;//提交OA时间
	
	@ExcelProperty(index = 16)
	private String refundTime;//财务退费时间

	public String getSortNo() {
		return sortNo;
	}

	public void setSortNo(String sortNo) {
		this.sortNo = sortNo;
	}

	public String getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getBankCardNo() {
		return bankCardNo;
	}

	public void setBankCardNo(String bankCardNo) {
		this.bankCardNo = bankCardNo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getOpenBankProvince() {
		return openBankProvince;
	}

	public void setOpenBankProvince(String openBankProvince) {
		this.openBankProvince = openBankProvince;
	}

	public String getOpenBankCity() {
		return openBankCity;
	}

	public void setOpenBankCity(String openBankCity) {
		this.openBankCity = openBankCity;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public Double getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(Double refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getCardId() {
		return cardId;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}


	public String getVehiclePate() {
		return vehiclePate;
	}

	public void setVehiclePate(String vehiclePate) {
		this.vehiclePate = vehiclePate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getRefundStatus() {
		return refundStatus;
	}

	public void setRefundStatus(String refundStatus) {
		this.refundStatus = refundStatus;
	}

	public String getRefundFailReason() {
		return refundFailReason;
	}

	public void setRefundFailReason(String refundFailReason) {
		this.refundFailReason = refundFailReason;
	}

	public String getSubmiteTime() {
		return submiteTime;
	}

	public void setSubmiteTime(String submiteTime) {
		this.submiteTime = submiteTime;
	}

	public String getRefundTime() {
		return refundTime;
	}

	public void setRefundTime(String refundTime) {
		this.refundTime = refundTime;
	}
	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	@Override
	public String toString() {
		return "CardRefundAccountBookInputDTO [sortNo=" + sortNo + ", serialNo=" + serialNo + ", phone=" + phone
				+ ", bankCardNo=" + bankCardNo + ", userName=" + userName + ", openBankProvince=" + openBankProvince
				+ ", openBankCity=" + openBankCity + ", bankName=" + bankName + ", branchName=" + branchName
				+ ", refundAmount=" + refundAmount + ", cardId=" + cardId + ", vehiclePate=" + vehiclePate + ", remark="
				+ remark + ", refundStatus=" + refundStatus + ", refundFailReason=" + refundFailReason
				+ ", submiteTime=" + submiteTime + ", refundTime=" + refundTime + "]";
	}


	

	
	
	
	
}
