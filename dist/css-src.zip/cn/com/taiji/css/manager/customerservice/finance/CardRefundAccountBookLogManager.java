package cn.com.taiji.css.manager.customerservice.finance;

import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.css.model.administration.refund.CardRefundBookLogPageRequest;
import cn.com.taiji.qtk.entity.CardRefundAccountBookLog;

public interface CardRefundAccountBookLogManager {

	Pagination pageQuery(CardRefundBookLogPageRequest queryModel);
	
	CardRefundAccountBookLog findById(String id);
	
}
