package cn.com.taiji.css.manager.customerservice.finance;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.css.model.administration.refund.CardRefundBookLogPageRequest;
import cn.com.taiji.qtk.entity.CardRefundAccountBookLog;
import cn.com.taiji.qtk.repo.jpa.CardRefundAccountBookLogRepo;

@Service
public class CardRefundAccountBookLogManagerImpl extends AbstractManager implements CardRefundAccountBookLogManager {

	@Autowired
	private CardRefundAccountBookLogRepo cardRefundAccountBookLogRepo;
	
	
	@Override
	public Pagination pageQuery(CardRefundBookLogPageRequest queryModel) {
		return cardRefundAccountBookLogRepo.page(queryModel);
	}

	@Override
	public CardRefundAccountBookLog findById(String id) {
		return cardRefundAccountBookLogRepo.getById(id);
	}

	
}
