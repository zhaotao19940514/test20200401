package cn.com.taiji.css.manager.customerservice.finance;

import java.io.File;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.css.entity.User;
import cn.com.taiji.css.model.administration.refund.CardRefundAccountBookPageRequest;
import cn.com.taiji.qtk.entity.CardRefundAccountBookDetail;

/**
 * 卡注销退款台账
 * 
 * @author
 *
 */
public interface CardRefundAccountBookManager {
	/**
	 * 导入Excel
	 * 
	 * @param file
	 * @param user
	 * @throws ManagerException
	 */
	public void uploadExcel(MultipartFile file, User user) throws ManagerException;

	/**
	 * 导出Excel
	 * 
	 * @param queryModle
	 * @param response
	 * @throws ManagerException
	 */
	public void exportExcel(CardRefundAccountBookPageRequest queryModle, HttpServletResponse response)
			throws ManagerException;

	/**
	 * 分页查询
	 * 
	 * @param queryModel
	 * @return
	 */
	Pagination pageQuery(CardRefundAccountBookPageRequest queryModel);

	/**
	 * 根据id查询
	 * 
	 * @param id
	 * @return
	 */
	CardRefundAccountBookDetail findById(String id);

	/**
	 * 数据修改
	 * 
	 * @param data
	 * @return
	 */
	public CardRefundAccountBookDetail updateData(CardRefundAccountBookDetail data,User user);

	/**
	 * 存放本地文件
	 * 
	 * @param file
	 * @return
	 * @throws ManagerException
	 */
	public void saveLocalFile(MultipartFile file) throws ManagerException;
	
	public File getExcelFilePath(CardRefundAccountBookPageRequest queryModel,User user) throws ManagerException;
}
