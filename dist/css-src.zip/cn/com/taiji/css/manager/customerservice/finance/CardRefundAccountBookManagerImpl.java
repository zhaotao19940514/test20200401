package cn.com.taiji.css.manager.customerservice.finance;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.google.common.collect.Lists;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.css.entity.User;
import cn.com.taiji.css.model.administration.refund.CardRefundAccountBookPageRequest;
import cn.com.taiji.qtk.entity.CardRefundAccountBookDetail;
import cn.com.taiji.qtk.entity.CardRefundAccountBookLog;
import cn.com.taiji.qtk.repo.jpa.AgencyRepo;
import cn.com.taiji.qtk.repo.jpa.CancelledCardDetailRepo;
import cn.com.taiji.qtk.repo.jpa.CardInfoRepo;
import cn.com.taiji.qtk.repo.jpa.CardRefundAccountBookDetailRepo;
import cn.com.taiji.qtk.repo.jpa.CardRefundAccountBookLogRepo;

@Service
public class CardRefundAccountBookManagerImpl extends AbstractManager implements CardRefundAccountBookManager {
	@Autowired
	private CardRefundAccountBookDetailRepo cardRefundAccountBookDetailRepo;
	
	@Autowired
	private CardRefundAccountBookLogRepo cardRefundAccountBookLogRepo;
	
	@Autowired
	private CardInfoRepo cardInfoRepo;

	private static final String CARD_REFUND_ACCOUNT_BOOK_PATH = "/home/filedata/cardrefundaccountbook";
	@Autowired
	private AgencyRepo agencyRepo;
	@Autowired
	private CancelledCardDetailRepo cancelRepo;

	@Override
	@Transactional
	public void uploadExcel(MultipartFile file, User user) throws ManagerException {
		EasyExcelListener listener = new EasyExcelListener(cardRefundAccountBookDetailRepo,user,cardInfoRepo,cardRefundAccountBookLogRepo,cancelRepo,file.getOriginalFilename(),agencyRepo);
		try {
			EasyExcel.read(file.getInputStream(), CardRefundAccountBookInputDTO.class, listener).sheet().doRead();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ManagerException("excel文件读取异常：" + e.getMessage());
		}
		saveLocalFile(file);// 存本地文件
//		updateOperationInfo(file,user);// 更新日志信息

	}

	@Override
	public void exportExcel(CardRefundAccountBookPageRequest queryModel, HttpServletResponse response)
			throws ManagerException {
		System.out.println(queryModel);
		Pagination page = cardRefundAccountBookDetailRepo.page(queryModel);
		List<CardRefundAccountBookDetail> result = page.getResult(CardRefundAccountBookDetail.class);
		List<CardRefundAccountBookOutputDTO> dtoList = Lists.newArrayList();
		result.forEach(c -> {
			CardRefundAccountBookOutputDTO dto = new CardRefundAccountBookOutputDTO();
			BeanUtils.copyProperties(c, dto);
			dtoList.add(dto);
		});
		response.setContentType("application/vnd.ms-excel");// 这是针对excel的contentType
		response.setCharacterEncoding("utf-8");//设置编码
		// 这里URLEncoder.encode可以防止中文乱码
		String fileName;
		try {
			fileName = URLEncoder.encode("easyExcelweb导出", "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			throw new ManagerException("导出EXCEL异常：" + e.getMessage());
		}
		;
		response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");// 设置响应头及excel文件名称
		EasyExcel.write(fileName, CardRefundAccountBookOutputDTO.class).sheet("sheet1").doWrite(dtoList);
	}

	@Override
	public Pagination pageQuery(CardRefundAccountBookPageRequest queryModel) {
		return cardRefundAccountBookDetailRepo.page(queryModel);
	}

	@Override
	public CardRefundAccountBookDetail findById(String id) {
		return cardRefundAccountBookDetailRepo.getById(id);
	}

	@Override
	@Transactional
	public CardRefundAccountBookDetail updateData(CardRefundAccountBookDetail data,User user) {
		
		CardRefundAccountBookDetail updateBefore = cardRefundAccountBookDetailRepo.getById(data.getId());
		CardRefundAccountBookDetail updateAfter = updateBefore;
		updateAfter.setRefundStatus(data.getRefundStatus());
		updateAfter.setRefundFailReason(data.getRefundFailReason());
		updateAfter.setSubmiteTime(data.getSubmiteTime());
		updateAfter.setRefundTime(data.getRefundTime());
		saveLog(updateAfter, user, updateBefore);
		return cardRefundAccountBookDetailRepo.save(updateAfter);
	}

	private void saveLog(CardRefundAccountBookDetail data, User user, CardRefundAccountBookDetail updateBefore) {
		CardRefundAccountBookLog log = new CardRefundAccountBookLog();
		BeanUtils.copyProperties(data, log,"id");
		log.setUpdateBeforeJson(JSON.toJSONString(updateBefore,SerializerFeature.WriteMapNullValue));
		log.setUpdateAfterJson(JSON.toJSONString(data,SerializerFeature.WriteMapNullValue));
		log.setCreateTime(new Date());
		log.setUpdateTime(new Date());
		log.setOperation("UPDATE");
		log.setStaffId(user.getStaffId());
		log.setStaffName(user.getStaff().getStaffName());
		log.setVehicleId(data.getVehiclePate());
		cardRefundAccountBookLogRepo.save(log);
	}

	@Override
	public void saveLocalFile(MultipartFile file) throws ManagerException {
		try {
			String fileName = file.getOriginalFilename();
			logger.info(fileName);
			File dirPath = new File(CARD_REFUND_ACCOUNT_BOOK_PATH);
			if (!dirPath.exists()) {
				dirPath.mkdirs();
			}
			File excelFile = new File(dirPath + "/" + fileName);
			if (!excelFile.exists()) {
				excelFile.getParentFile().mkdirs();
			}
			file.transferTo(excelFile); // 保存文件
		} catch (Exception e) {
			e.printStackTrace();
			throw new ManagerException("excel文件存入服务器失败：" + e.getMessage());
		}

	}
	@Transactional
	public File getExcelFilePath(CardRefundAccountBookPageRequest queryModel,User user) throws ManagerException {
		//queryModel.paramCheck();
		File file = new File("/home/filedata/refundExport/"+System.currentTimeMillis()+".xlsx");
	    //视图结果集
		List<CardRefundAccountBookDetail> listByCancelTime = cardRefundAccountBookDetailRepo.listByCancelTime(queryModel.getStartRefundTime(), queryModel.getEndRefundTime());
	    System.out.println("listByCancelTime==="+listByCancelTime.size());
	    List<String> cards=new ArrayList<String>();
        // 创建excel
        HSSFWorkbook wk = new HSSFWorkbook();
        // 创建一张工作表
        HSSFSheet sheet = wk.createSheet();
        // 2
        sheet.setDefaultColumnWidth(20);
        sheet.setDefaultRowHeightInPoints(20*100);
        HSSFRow row = sheet.createRow(0);
        // 创建第一行的第一个单元格
        // 想单元格写值
        HSSFCell cell = row.createCell((short) 0);
        cell.setCellValue("编号");
        cell = row.createCell((short)1);
        cell.setCellValue("OA号");
        cell = row.createCell((short)2);
        cell.setCellValue("手机号");
        cell = row.createCell((short)3);
        cell.setCellValue("银行卡号");
        cell = row.createCell((short)4);
        cell.setCellValue("用户名");
        cell = row.createCell((short)5);
        cell.setCellValue("开户行所在省");
        cell = row.createCell((short)6);
        cell.setCellValue("开户行所在市");
        cell = row.createCell((short)7);
        cell.setCellValue("银行名");
        cell = row.createCell((short)8);
        cell.setCellValue("支行名称");
        cell = row.createCell((short)9);
        cell.setCellValue("退费金额");
        cell = row.createCell((short)10);
        cell.setCellValue("ETC卡号");
        cell = row.createCell((short)11);
        cell.setCellValue("卡注销时间");
        cell = row.createCell((short)12);
        cell.setCellValue("车牌号");
        cell = row.createCell((short)13);
        cell.setCellValue("备注");
        cell = row.createCell((short)14);
        cell.setCellValue("退费状态");
        cell = row.createCell((short)15);
        cell.setCellValue("退费失败原因");
        cell = row.createCell((short)16);
        cell.setCellValue("提交OA时间");
        cell = row.createCell((short)17);
        cell.setCellValue("财务退费时间");
        cell = row.createCell((short)18);
        cell.setCellValue("发卡渠道编号");
        cell = row.createCell((short)19);
        cell.setCellValue("发卡渠道名称");
        cell = row.createCell((short)20);
        
        // 创建第一行
        for (short i=0;i<listByCancelTime.size();i++)
        {
        		row = sheet.createRow(i+1);
        		row.createCell(0).setCellValue(listByCancelTime.get(i).getSortNo());
        		row.createCell(1).setCellValue(listByCancelTime.get(i).getSerialNo());
        		row.createCell(2).setCellValue(listByCancelTime.get(i).getPhone());
        		row.createCell(3).setCellValue(listByCancelTime.get(i).getBankCardNo());  
        		row.createCell(4).setCellValue(listByCancelTime.get(i).getUserName());
        		row.createCell(5).setCellValue(listByCancelTime.get(i).getOpenBankProvince());
        		row.createCell(6).setCellValue(listByCancelTime.get(i).getOpenBankCity());
        		row.createCell(7).setCellValue(listByCancelTime.get(i).getBankName());
        		row.createCell(8).setCellValue(listByCancelTime.get(i).getBranchName());
        		row.createCell(9).setCellValue(listByCancelTime.get(i).getRefundAmount());
        		row.createCell(10).setCellValue(listByCancelTime.get(i).getCardId());
        		row.createCell(11).setCellValue(listByCancelTime.get(i).getCardCancelTime());
        		row.createCell(12).setCellValue(listByCancelTime.get(i).getVehiclePate());
        		row.createCell(13).setCellValue(listByCancelTime.get(i).getRemark());
        		row.createCell(14).setCellValue(listByCancelTime.get(i).getRefundStatus());
        		row.createCell(15).setCellValue(listByCancelTime.get(i).getRefundFailReason());
        		row.createCell(16).setCellValue(listByCancelTime.get(i).getSubmiteTime());
        		row.createCell(17).setCellValue(listByCancelTime.get(i).getRefundTime());
        		row.createCell(18).setCellValue(listByCancelTime.get(i).getAgencyId());
        		row.createCell(19).setCellValue(listByCancelTime.get(i).getAgencyName());
        }
       try {
           wk.write(new FileOutputStream(file));
           wk.close();
	} catch (IOException e) {
		e.printStackTrace();
		throw new ManagerException("关闭流出错,请联系管理员");
	}finally {
		
	}
       return file;
	}
}
