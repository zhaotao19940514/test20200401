package cn.com.taiji.css.manager.customerservice.finance;

import java.io.Serializable;

import com.alibaba.excel.annotation.ExcelProperty;

@SuppressWarnings("serial")
public class CardRefundAccountBookOutputDTO implements Serializable {

	@ExcelProperty("编号")
	private Integer sortNo;//编号
	
	@ExcelProperty("OA号")
	private String serialNo;//OA号

	@ExcelProperty("OA号")
	private String phone;//电话
	
	@ExcelProperty("银行卡号")
	private String bankCardNo;//银行卡号
	
	@ExcelProperty("用户名")
	private String userName;//用户名
	
	@ExcelProperty("开户行所在省")
	private String openBankProvince;//开户行所在省
	
	@ExcelProperty("开户行所在市")
	private String openBankCity;//开户行所在市
	
	@ExcelProperty("银行名")
	private String bankName;//银行名
	
	@ExcelProperty("退费额金额")
	private Double refundAmount;//退费额金额
	
	@ExcelProperty("ETC卡号")
	private String cardId;//ETC卡号
	
	@ExcelProperty("卡注销时间")
	private String cardCancelTime;//卡注销时间
	
	@ExcelProperty("车牌号")
	private String vehiclePate;//车牌号
	
	@ExcelProperty("备注")
	private String remark;//备注
	
	@ExcelProperty("退费状态")
	private String refundStatus;//退费状态
	
	@ExcelProperty("退费失败原因")
	private String refundFailReason;//退费失败原因
	
	@ExcelProperty("提交OA时间")
	private String submiteTime;//提交OA时间
	
	@ExcelProperty("财务退费时间")
	private String refundTime;//财务退费时间
	
	@ExcelProperty("发卡渠道编号")
	private String agencyId;//发卡渠道编号
	
	@ExcelProperty("发卡渠道名称")
	private String agencyName;//发卡渠道名称

	public Integer getSortNo() {
		return sortNo;
	}

	public void setSortNo(Integer sortNo) {
		this.sortNo = sortNo;
	}

	public String getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getBankCardNo() {
		return bankCardNo;
	}

	public void setBankCardNo(String bankCardNo) {
		this.bankCardNo = bankCardNo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getOpenBankProvince() {
		return openBankProvince;
	}

	public void setOpenBankProvince(String openBankProvince) {
		this.openBankProvince = openBankProvince;
	}

	public String getOpenBankCity() {
		return openBankCity;
	}

	public void setOpenBankCity(String openBankCity) {
		this.openBankCity = openBankCity;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public Double getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(Double refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getCardId() {
		return cardId;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	public String getCardCancelTime() {
		return cardCancelTime;
	}

	public void setCardCancelTime(String cardCancelTime) {
		this.cardCancelTime = cardCancelTime;
	}

	public String getVehiclePate() {
		return vehiclePate;
	}

	public void setVehiclePate(String vehiclePate) {
		this.vehiclePate = vehiclePate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getRefundStatus() {
		return refundStatus;
	}

	public void setRefundStatus(String refundStatus) {
		this.refundStatus = refundStatus;
	}

	public String getRefundFailReason() {
		return refundFailReason;
	}

	public void setRefundFailReason(String refundFailReason) {
		this.refundFailReason = refundFailReason;
	}

	public String getSubmiteTime() {
		return submiteTime;
	}

	public void setSubmiteTime(String submiteTime) {
		this.submiteTime = submiteTime;
	}

	public String getRefundTime() {
		return refundTime;
	}

	public void setRefundTime(String refundTime) {
		this.refundTime = refundTime;
	}

	public String getAgencyId() {
		return agencyId;
	}

	public void setAgencyId(String agencyId) {
		this.agencyId = agencyId;
	}

	public String getAgencyName() {
		return agencyName;
	}

	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}
	
	
	

}
