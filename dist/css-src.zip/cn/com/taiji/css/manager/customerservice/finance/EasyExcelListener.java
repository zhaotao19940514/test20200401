package cn.com.taiji.css.manager.customerservice.finance;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.google.common.collect.Lists;

import cn.com.taiji.css.entity.User;
import cn.com.taiji.qtk.entity.Agency;
import cn.com.taiji.qtk.entity.CardInfo;
import cn.com.taiji.qtk.entity.CardRefundAccountBookDetail;
import cn.com.taiji.qtk.entity.CardRefundAccountBookLog;
import cn.com.taiji.qtk.repo.jpa.AgencyRepo;
import cn.com.taiji.qtk.repo.jpa.CancelledCardDetailRepo;
import cn.com.taiji.qtk.repo.jpa.CardInfoRepo;
import cn.com.taiji.qtk.repo.jpa.CardRefundAccountBookDetailRepo;
import cn.com.taiji.qtk.repo.jpa.CardRefundAccountBookLogRepo;

public class EasyExcelListener extends AnalysisEventListener<CardRefundAccountBookInputDTO> {
	Logger logger = LoggerFactory.getLogger(EasyExcelListener.class);

	private List<CardRefundAccountBookInputDTO> datas = Lists.newArrayList();

	private static final int BATCH_COUNT = 1000;// 当数据量达到1000时进行存储工作，防止oom

	private CardRefundAccountBookDetailRepo cardRefundAccountBookDetailRepo;
	
    private CardInfoRepo cardInfoRepo;
    
    private User user;
    
    private CardRefundAccountBookLogRepo cardRefundAccountBookLogRepo;
    
    private String fileName;
    
    private AgencyRepo agencyRepo;
    
    private CancelledCardDetailRepo cancelRepo;
    


	@Override
	public void invoke(CardRefundAccountBookInputDTO t, AnalysisContext analysisContext) {
		logger.info("解析到一条数据:{}", JSON.toJSONString(t, SerializerFeature.WriteMapNullValue));
		datas.add(t);
		if (datas.size() >= BATCH_COUNT) {
			saveData();// 保存入库
			datas.clear();
		}
	}

	public EasyExcelListener(CardRefundAccountBookDetailRepo cardRefundAccountBookDetailRepo,User user,CardInfoRepo cardInfoRepo,CardRefundAccountBookLogRepo cardRefundAccountBookLogRepo,CancelledCardDetailRepo cancelRepo,String fileName,AgencyRepo agencyRepo) {
		this.cardRefundAccountBookDetailRepo = cardRefundAccountBookDetailRepo;
		this.user =user;
		this.cardInfoRepo =cardInfoRepo;
		this.cardRefundAccountBookLogRepo =cardRefundAccountBookLogRepo;
		this.fileName =fileName;
		this.agencyRepo = agencyRepo;
		this.cancelRepo = cancelRepo;
	}

	@Override
	public void doAfterAllAnalysed(AnalysisContext analysisContext) {
		saveData();
	}

	@Transactional
	public void saveData() {
		List<CardRefundAccountBookDetail> entityList = Lists.newArrayList();
		datas.forEach(c -> {
			CardRefundAccountBookDetail entity = new CardRefundAccountBookDetail();
			BeanUtils.copyProperties(c, entity,"cardCancelTime");
			entity.setCreateTime(new Date());
			entity.setUpdateTime(new Date());
			//TODO set 关联渠道 
			Agency agency = agencyByCardId(entity.getCardId());
			if(null!=agency&&!agency.equals("")) {
				entity.setAgencyId(agency.getAgencyId());
				entity.setAgencyName(agency.getName());
			}
			entity.setCardCancelTime(cancelRepo.findByCardId(entity.getCardId())==null?"":new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(cancelRepo.findByCardId(entity.getCardId()).getCreateTime().getTime()));
			//TODO set User信息
			entity.setLoginAgencyId(user.getStaff().getAgencyId());
			entity.setLoginUserName(user.getStaff().getStaffId());
			entity.setLoginServiceHallId(user.getStaff().getServiceHall().getServiceHallId());
			entity.setStaffId(user.getStaff().getStaffId());
			//TODO set Log信息
			entity.setFileName(fileName);
			entityList.add(entity);
			convertLog(entity);
		});
		logger.info("保存数据集合长度:{}", entityList.size());
		if (entityList.size() == 0 || entityList.isEmpty())
			return;
		cardRefundAccountBookDetailRepo.saveAll(entityList);
	}
	//关联渠道
	private Agency agencyByCardId(String cardId) {
		CardInfo cardInfo = cardInfoRepo.findByCardId(cardId);
		if(null!=cardInfo) {
			return agencyRepo.findByAgencyId(cardInfo.getAgencyId());
		}
		return null;
		
	}
	private CardRefundAccountBookLog convertLog(CardRefundAccountBookDetail detail) {
	CardRefundAccountBookLog log = new CardRefundAccountBookLog();
	BeanUtils.copyProperties(detail, log,"id");
	log.setStaffName(detail.getLoginUserName());
	log.setVehicleId(detail.getVehiclePate());
	log.setCreateTime(new Date());
	log.setUpdateTime(new Date());
	log.setOperation("ADD");
	cardRefundAccountBookLogRepo.persist(log);
	return log;
}
}
