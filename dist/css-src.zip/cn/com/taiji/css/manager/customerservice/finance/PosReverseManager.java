package cn.com.taiji.css.manager.customerservice.finance;

import java.util.List;

import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.css.entity.User;
import cn.com.taiji.qtk.entity.CssPosTradeDetail;

public interface PosReverseManager {

	List<CssPosTradeDetail> findByReferNo(Integer referNo,User user) throws ManagerException;

	void save(String resPonse, User user);

}
