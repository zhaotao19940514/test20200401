/**
 * @Title RechargeManager.java
 * @Package cn.com.taiji.css.manager.customerservice.finance
 * @Description TODO
 * @author yaonanlin
 * @date 2018年6月25日 下午5:16:25
 * @version V1.0
 */
package cn.com.taiji.css.manager.customerservice.obu;

import cn.com.taiji.common.manager.ManagerException;

/**
 * @ClassName CancelManager.java
 * @author fxd
 * @Description 
 * @date2019年08月19日
 */
public interface Obu4XCheckFromPcManager {

	public boolean check4X(String obuId) throws ManagerException;

}

