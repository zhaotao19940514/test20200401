
package cn.com.taiji.css.manager.customerservice.report;

import javax.servlet.http.HttpServletRequest;

import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.css.model.customerservice.report.BusinessstatementResponse;
import cn.com.taiji.css.model.customerservice.report.FinancialstatementRequest;


public interface BusinessstatementManager {

	/**
	 * @param queryModelO
	 * @return
	 * @throws ManagerException 
	 */
	BusinessstatementResponse queryPage(FinancialstatementRequest queryModel,HttpServletRequest request) throws ManagerException;
}

