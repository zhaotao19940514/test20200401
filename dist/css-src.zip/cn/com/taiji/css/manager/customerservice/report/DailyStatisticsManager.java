package cn.com.taiji.css.manager.customerservice.report;

public interface DailyStatisticsManager {
	
	void run(String date);
	
	
}
