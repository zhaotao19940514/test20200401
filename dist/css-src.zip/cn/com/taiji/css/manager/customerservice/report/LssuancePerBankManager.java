package cn.com.taiji.css.manager.customerservice.report;

import java.io.File;
import java.util.Map;

import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.css.model.customerservice.report.QueryTimes;

public interface LssuancePerBankManager {
	
	Map<?, ?> page(QueryTimes queryModel) throws ManagerException;

	File getResult(QueryTimes qm) throws Exception;

}
