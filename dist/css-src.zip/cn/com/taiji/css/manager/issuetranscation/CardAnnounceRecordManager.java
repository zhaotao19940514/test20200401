package cn.com.taiji.css.manager.issuetranscation;

import cn.com.taiji.common.model.dao.LargePagination;
import cn.com.taiji.css.model.issuetranscation.CardAnnounceRecordRequest;

public interface CardAnnounceRecordManager {
	LargePagination<CardAnnounceRecordModel> queryPage(CardAnnounceRecordRequest request);
}
