package cn.com.taiji.css.manager.issuetranscation;

import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.css.model.issuetranscation.CardConsumptionRequest;

public interface CardConsumptionManager {
	Pagination page(CardConsumptionRequest request);
}
