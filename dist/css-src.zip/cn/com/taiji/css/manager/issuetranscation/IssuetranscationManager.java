package cn.com.taiji.css.manager.issuetranscation;

import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.css.model.appajax.AppAjaxResponse;
import cn.com.taiji.css.model.issuetranscation.IssueTranscationRequest;

public interface IssuetranscationManager {
	Pagination page(IssueTranscationRequest request);

	AppAjaxResponse update(String rowId);
}
