/**
 * @Title OcxTestManager.java
 * @Package cn.com.taiji.css.manager.ocxtest
 * @Description TODO
 * @author yaonanlin
 * @date 2018年7月12日 下午4:35:52
 * @version V1.0
 */
package cn.com.taiji.css.manager.ocxtest;

import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.css.model.ocxtest.TestApplyCardRequest;
import cn.com.taiji.css.model.ocxtest.TestApplyCardResponse;

/**
 * @ClassName OcxTestManager
 * @Description TODO
 * @author yaonl
 * @date 2018年07月12日 16:35:52
 * @E_mail yaonanlin@163.com
 */
public interface CardOcxTestManager {
	public TestApplyCardResponse applyCard(TestApplyCardRequest applyCardModel) throws ManagerException;
}

