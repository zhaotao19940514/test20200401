package cn.com.taiji.css.manager.qtzt;

import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.css.model.qtzt.QtztJsonRequest;
import cn.com.taiji.css.model.qtzt.QtztJsonResponse;


public interface QtztInterfaceJsonManager {
   public  QtztJsonResponse sendQtzt(QtztJsonRequest request,Class<? extends QtztJsonResponse> typeClass) throws ManagerException;
   

}
