package cn.com.taiji.css.manager.qtzt;

public enum QtztTransType {
	ISSUEORDER("ISSUEORDER","创建汇联通发行订单","/common/req","IF010012019062510002"){},
	AGENCYCARDBLACKREASON("AGENCYCARDBLACKREASON","机构卡黑原因查询","/common/req","IF01001202006110408"){},
	
	;
	private String type;
	private String info;
	private String url;
	private String code;
	
	private QtztTransType(String type, String info, String url, String code) {
		this.type = type;
		this.info = info;
		this.url = url;
		this.code = code;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
}
