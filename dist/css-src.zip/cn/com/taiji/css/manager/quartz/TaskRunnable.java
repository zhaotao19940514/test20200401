/*
 * Date: 2013年8月9日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.css.manager.quartz;

import cn.com.taiji.css.config.manager.TaskInfo;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013年8月9日 上午10:41:46<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface TaskRunnable extends Runnable
{
	public TaskInfo getTaskInfo();
}
