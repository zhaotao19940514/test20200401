package cn.com.taiji.css.manager.query.agency;

import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.css.model.qtzt.request.AgencyCardBlackReasonRequestData;
import cn.com.taiji.css.model.qtzt.response.AgencyCardBlackReasonResponseData;
import cn.com.taiji.css.model.query.AgencyCardBlackReasonRequest;

public interface AgencyCardBlackReasonManager {

	AgencyCardBlackReasonResponseData agencyCardBlackReason(AgencyCardBlackReasonRequestData reqData, String orgCode)
			throws ManagerException;

	String cardBlackReasonQuery(AgencyCardBlackReasonRequest req) throws ManagerException;
	
}
