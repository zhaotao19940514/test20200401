package cn.com.taiji.css.manager.query.agency;

import java.util.HashMap;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Maps;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.css.manager.qtzt.QtztInterfaceJsonManager;
import cn.com.taiji.css.model.qtzt.QtztJsonRequest;
import cn.com.taiji.css.model.qtzt.request.AgencyCardBlackReasonRequestData;
import cn.com.taiji.css.model.qtzt.response.AgencyCardBlackReasonResponse;
import cn.com.taiji.css.model.qtzt.response.AgencyCardBlackReasonResponseData;
import cn.com.taiji.css.model.query.AgencyCardBlackReasonRequest;

@Service
public class AgencyCardBlackReasonManagerImpl extends AbstractManager implements AgencyCardBlackReasonManager {

	@Autowired
	private QtztInterfaceJsonManager qtztInterfaceJsonManager;
	@Override
	public String cardBlackReasonQuery(AgencyCardBlackReasonRequest req) throws ManagerException {
		req.validate();
		AgencyCardBlackReasonRequestData reqData = new AgencyCardBlackReasonRequestData();
		reqData.setCardId(req.getCardId());
		String str = "";
		try {
			AgencyCardBlackReasonResponseData reason = agencyCardBlackReason(reqData, req.getOrgCode());
			if(reason != null) {
				if(reason.getRc() != null && "0".equals(reason.getRc())) {
					str = "<font color=\"red\">查询结果：</font>成功<br><font color=\"red\">下黑原因：</font>" + reason.getRmsg();
				}else {
					str = "<font color=\"red\">查询结果：</font>失败<br><font color=\"red\">下黑原因：</font>" + reason.getRmsg();
				}
			}else {
				str = "未获取到渠道的响应结果！";
			}
		} catch (ManagerException e) {
			e.printStackTrace();
			str = e.getMessage();
		} catch (Exception e) {
			str = ExceptionUtils.getStackTrace(e);
		}
		return str;
	}
	@Override
	public AgencyCardBlackReasonResponseData agencyCardBlackReason(AgencyCardBlackReasonRequestData reqData, String orgCode) throws ManagerException {
		QtztJsonRequest req = new QtztJsonRequest();
		req.setData(reqData);
		req.setOrgCode(orgCode);
		AgencyCardBlackReasonResponse res = (AgencyCardBlackReasonResponse) qtztInterfaceJsonManager.sendQtzt(req,AgencyCardBlackReasonResponse.class);
		if(res != null && res.getRcode() != null && res.getRcode() == 0 && res.getData() != null) {
			return res.getData();
		}else if(res != null){
			throw new ManagerException("查询失败！中台响应码：" + rmsgSplit(res.getRmsg()).get("rc") + ",描述：" + rmsgSplit(res.getRmsg()).get("rmsg"));
		}else {
			throw new ManagerException("请求中台网络开小差啦,请稍后再试！");
		}
	}
	private HashMap<String, String> rmsgSplit(String str) {
		HashMap<String, String> map = Maps.newHashMap();
		int start = str.indexOf("{");
		int end = str.indexOf("}");
		str = str.substring(start+1, end);
		logger.info(str);
		str = str.replace("\\\"", "");
		logger.info(str);
		String[] split = str.split(",");
		for (String temp : split) {
			String[] split2 = temp.split(":");
			if(split2.length == 2 && hasText(split2[0]) && hasText(split2[1])) {
				map.put(split2[0], split2[1]);
			}
		}
		return map;
	}
	private void saveCommParam(QtztJsonRequest req) {
		req.setTerminalId("020000000000");
		req.setStaffId("test01");
		req.setAgentId("52010188037");
		req.setChannelId("5201018803701150001");
		req.setChannelType(2);
	}
}
