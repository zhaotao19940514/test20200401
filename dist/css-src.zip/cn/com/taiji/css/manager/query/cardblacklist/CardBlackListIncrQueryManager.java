package cn.com.taiji.css.manager.query.cardblacklist;

import cn.com.taiji.common.model.dao.LargePagination;
import cn.com.taiji.css.repo.request.cardblacklist.CardBLackListIncrQueryRequest;
import cn.com.taiji.qtk.entity.CardBlackListIncr;

public interface CardBlackListIncrQueryManager{
	
	LargePagination<CardBlackListIncr> findById(CardBLackListIncrQueryRequest req);
//	List<CardBlackList> findById(CardBLackListQueryRequest req);
}
