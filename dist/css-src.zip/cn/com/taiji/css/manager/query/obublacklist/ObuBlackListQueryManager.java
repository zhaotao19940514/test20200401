package cn.com.taiji.css.manager.query.obublacklist;

import cn.com.taiji.common.model.dao.LargePagination;
import cn.com.taiji.css.repo.request.obublacklist.ObuBLackListQueryRequest;
import cn.com.taiji.qtk.entity.ObuBlackList;

public interface ObuBlackListQueryManager{
	
	LargePagination<ObuBlackList> findById(ObuBLackListQueryRequest req);
//	List<ObuBlackList> findById(ObuBLackListQueryRequest req);
}
