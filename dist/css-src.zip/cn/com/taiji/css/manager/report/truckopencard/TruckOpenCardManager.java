package cn.com.taiji.css.manager.report.truckopencard;

import java.util.List;

import cn.com.taiji.css.model.customerservice.report.QueryTimes;

public interface TruckOpenCardManager {
	
	public List<Object[]> page(QueryTimes time);
	
}
