/*
 * Date: 2012-3-7
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.css.manager.system;

import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.css.repo.request.system.ScheduleLogPageRequest;

/**
 * 
 * @author Peream <br>
 *         Create Time：2012-3-7 下午3:12:06<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface ScheduleLogManager
{
	public Pagination queryPage(ScheduleLogPageRequest req);
}
