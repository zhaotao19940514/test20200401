package cn.com.taiji.css.model;

import cn.com.taiji.common.model.finals.SysFinals;

/**
 * 
 * @author Peream <br>
 *         Create Time：2010-9-10 下午04:13:09<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class MyFinals extends SysFinals
{
	public static String COOKIE_USER = "mycookieuser";
	public static String COOKIE_PASS = "mycookiepass";

	public final static String CRON_TASK_TABLE = "SAMPLE_CRON_EXCLUSIVE_TASK";
	public final static String QUICK_APPLY_CUSTOMER_IMG = "quickApplyCustomerImg";
	public final static String QUICK_APPLY_VEHICLE_IMG = "quickApplyVehicleImg";
	public final static String NOTIFY_CONTENT_IMG = "notifyContentImg";
	public final static String HALFAUDITING_IMG = "halfauditingImg";
	public final static String REFUND_FILE = "refundFile";
	public final static String BATCHISSUEBASEINFO = "batchIssueBaseInfo";
	public final static String CANCEL_REFUND_FILE = "cancelRefundFile";
	public final static String EXPENSE_REFUND_APPLY_FILE = "expenseRefundApplyFile";
	public final static String EXPENSE_REFUND_FILE = "expenseRefundFile";
	public final static String CANCEL_CUSCONFIRM_IMG = "cancelCusConfirmImg";
	public final static String CANCEL_REFUND_RESPONSE = "cancelRefundResponse";
	public static final String UTF8 = "UTF-8";
	public final static Integer TAX_INFO_COLNUMS=8;
	public final static Integer TAX_INFO_SERVICE=7;
	public final static Integer EXPENSE_REFUND_VALUE=11;
	public final static Integer IMPORT_PAGE_SIZE=1;
	public final static Integer INPORT_INFO_SERVICE=47;
	public final static Integer REFUND_INFO_SERVICE=7;
}
