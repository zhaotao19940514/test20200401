/*
 * Date: 2013年9月4日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.css.model;

import cn.com.taiji.common.model.BaseModel;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013年9月4日 上午9:35:16<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class SessionTicket extends BaseModel
{
	private String ticketId;
	private String sessionId;
	private long time;

	public String getTicketId()
	{
		return ticketId;
	}

	public String getSessionId()
	{
		return sessionId;
	}

	public long getTime()
	{
		return time;
	}

	public void setTicketId(String ticketId)
	{
		this.ticketId = ticketId;
	}

	public void setSessionId(String sessionId)
	{
		this.sessionId = sessionId;
	}

	public void setTime(long time)
	{
		this.time = time;
	}

}
