/*
 * Date: 2014年10月15日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.css.model.acl;

import cn.com.taiji.common.model.BaseModel;

/**
 * 
 * @author Peream <br>
 *         Create Time：2014年10月15日 下午6:29:39<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class HasButtonModel extends BaseModel
{
	private String uri;
	private boolean hasButton;
	private String msg;

	public HasButtonModel()
	{

	}

	public HasButtonModel(String uri, boolean hasButton, String msg)
	{
		this.uri = uri;
		this.hasButton = hasButton;
		this.msg = msg;
	}

	public String getUri()
	{
		return uri;
	}

	public void setUri(String uri)
	{
		this.uri = uri;
	}

	public boolean isHasButton()
	{
		return hasButton;
	}

	public String getMsg()
	{
		return msg;
	}

	public void setHasButton(boolean hasButton)
	{
		this.hasButton = hasButton;
	}

	public void setMsg(String msg)
	{
		this.msg = msg;
	}

}
