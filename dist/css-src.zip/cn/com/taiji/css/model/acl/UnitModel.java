package cn.com.taiji.css.model.acl;

import cn.com.taiji.css.entity.Unit;

public class UnitModel extends Unit {

	private boolean hasChild;

	public boolean isHasChild() {
		return hasChild;
	}

	public void setHasChild(boolean hasChild) {
		this.hasChild = hasChild;
	}
	
	
}
