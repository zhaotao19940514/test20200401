package cn.com.taiji.css.model.administration.inventory;

import cn.com.taiji.common.model.BaseModel;

public class CardEndCalculateRequest extends BaseModel{
	private String startId;
	private Integer inboundNum;
	private Integer outboundNum;
	public String getStartId() {
		return startId;
	}
	public void setStartId(String startId) {
		this.startId = startId;
	}
	public Integer getInboundNum() {
		return inboundNum;
	}
	public void setInboundNum(Integer inboundNum) {
		this.inboundNum = inboundNum;
	}
	public Integer getOutboundNum() {
		return outboundNum;
	}
	public void setOutboundNum(Integer outboundNum) {
		this.outboundNum = outboundNum;
	}
}
