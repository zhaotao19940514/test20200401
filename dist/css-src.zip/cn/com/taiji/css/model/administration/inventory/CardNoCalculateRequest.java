package cn.com.taiji.css.model.administration.inventory;

import cn.com.taiji.common.model.BaseModel;

public class CardNoCalculateRequest extends BaseModel {
	private String startId;
	private Integer inBoundNum;
	private Integer outBoundNum;
	public String getStartId() {
		return startId;
	}
	public void setStartId(String startId) {
		this.startId = startId;
	}
	public Integer getInBoundNum() {
		return inBoundNum;
	}
	public void setInBoundNum(Integer inBoundNum) {
		this.inBoundNum = inBoundNum;
	}
	public Integer getOutBoundNum() {
		return outBoundNum;
	}
	public void setOutBoundNum(Integer outBoundNum) {
		this.outBoundNum = outBoundNum;
	}
	
}
