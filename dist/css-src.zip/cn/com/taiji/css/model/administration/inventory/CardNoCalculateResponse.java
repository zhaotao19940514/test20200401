package cn.com.taiji.css.model.administration.inventory;

import cn.com.taiji.common.model.BaseModel;

public class CardNoCalculateResponse extends BaseModel {
	private String endId;
	public String getEndId() {
		return endId;
	}
	public void setEndId(String endId) {
		this.endId = endId;
	}
}
