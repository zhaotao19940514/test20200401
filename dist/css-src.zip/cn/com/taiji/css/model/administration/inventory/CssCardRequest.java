package cn.com.taiji.css.model.administration.inventory;

import cn.com.taiji.common.model.BaseModel;

public class CssCardRequest extends BaseModel{
	private String id;
	private String type;
	private String model;
	private String brand;
	private String remarks;
	private String handleDate;
	private String obrand;
	
	public CssCardRequest() {
		if("3".equals(type)) {
			brand = obrand;
		}
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getHandleDate() {
		return handleDate;
	}
	public void setHandleDate(String handleDate) {
		this.handleDate = handleDate;
	}
	public String getObrand() {
		return obrand;
	}
	public void setObrand(String obrand) {
		this.obrand = obrand;
	}
	
}
