package cn.com.taiji.css.model.administration.inventory;

import cn.com.taiji.dsi.model.common.storage.OBUInBoundResponse;
import cn.com.taiji.qtk.entity.StorageObuInfoBatch;

public class ObuInBoundAppResponse extends OBUInBoundResponse {
	private StorageObuInfoBatch storageObuInfoBatch;
	public StorageObuInfoBatch getStorageObuInfoBatch() {
		return storageObuInfoBatch;
	}
	public void setStorageObuInfoBatch(StorageObuInfoBatch storageObuInfoBatch) {
		this.storageObuInfoBatch = storageObuInfoBatch;
	}
}
