package cn.com.taiji.css.web.administration.obubrandperiod;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.common.manager.net.http.HttpMimeResponseHelper;
import cn.com.taiji.common.web.BaseDownloadController;
import cn.com.taiji.css.entity.User;
import cn.com.taiji.css.manager.administration.obubrandperiod.ObuBrandPeriodManager;
import cn.com.taiji.css.model.UserRequset;
import cn.com.taiji.css.model.administration.obubrandperiod.ObuBrandPeriodRequest;
import cn.com.taiji.css.model.administration.obubrandperiod.ObuBrandPeriodResponse;

@Controller
@RequestMapping("/administration/obubrandperiod")
public class ObuBrandPeriodController extends BaseDownloadController{

	private final String prefix = "administration/obubrandperiod/";

	@Autowired
	private ObuBrandPeriodManager obuBrandPeriodManager;

	@RequestMapping(value = "/manage", method = RequestMethod.GET)
	public String manageGet(@ModelAttribute("queryModel") ObuBrandPeriodRequest queryModel, Model model) {
		return prefix + "manage";
	}

	@RequestMapping(value = "/manage", method = RequestMethod.POST)
	public String managePost(@ModelAttribute("queryModel") ObuBrandPeriodRequest queryModel, Model model,
			HttpServletResponse response) throws IOException {
		return prefix + "manage";
	}

	@RequestMapping(value = "/file", method = RequestMethod.GET)
	public String setupFile(@ModelAttribute("pageModel") User user, HttpServletRequest request, Model model) {
		return prefix + "file";
	}
	
	//保存文件
	@RequestMapping(value = "/handleFile", method = RequestMethod.POST)
	public void fileUpload(HttpServletRequest request, @RequestParam("file") MultipartFile file,
			HttpServletResponse response) {
		System.out.println("服务器保存文件开始！");
		ObuBrandPeriodResponse res = new ObuBrandPeriodResponse();
		try {
			res = obuBrandPeriodManager.saveFile(file);
			HttpMimeResponseHelper.responseJson(res.toJson(), response);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("服务器保存文件结束！");
	}
	
	//根据车牌ID获取OBU明细
	@RequestMapping(value = "/importExcel", method = RequestMethod.POST)
	public void loginPost(@RequestBody UserRequset queryModel, HttpServletRequest request,
			HttpServletResponse response, Model model) throws ManagerException {
		File f = new File(queryModel.getFilePath() + queryModel.getFileName());
		try {
			obuBrandPeriodManager.importExcel(obuBrandPeriodManager.getLines(f));
		} catch (IOException e) {
			throw new ManagerException("读取Excel文件失败，请重新上传！", e);
		} catch (ManagerException e) {
			throw new ManagerException("读取Excel文件失败，请重新上传！", e);
		}

		System.out.println("生成表格开始......");
		File file = obuBrandPeriodManager.getExcelFilePath(request);
		System.out.println("生成表格结束......");
		try {
			System.out.println("返回文件开始......");
			HttpMimeResponseHelper.doDownLoad(request, response, file, file.getName());
		} catch (IOException e) {
			e.printStackTrace();
			throw new ManagerException("下载文件失败", e);
		}
		System.out.println("返回文件结束......");
	}
	
	//根据时间段统计各渠道厂家OBU数据
	@RequestMapping(value = "/exportExcel", method = RequestMethod.POST)
	public void getExcelFile(@RequestBody ObuBrandPeriodRequest queryModel, HttpServletRequest request, Model model,
			HttpServletResponse response) throws ManagerException {
		//获取时间段
		String startTime = queryModel.getStartTime();
		String endTime = queryModel.getEndTime();
		System.out.println("查询数据并生成EXcel开始");
		File export = obuBrandPeriodManager.queryByDate(startTime,endTime);
		System.out.println("查询数据并生成EXcel结束");
		try {
			HttpMimeResponseHelper.doDownLoad(request, response, export, export.getName());
		} catch (IOException e) {
			e.printStackTrace();
			throw new ManagerException("下载文件失败", e);
		}
	}
}
