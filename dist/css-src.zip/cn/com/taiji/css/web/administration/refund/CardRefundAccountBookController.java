package cn.com.taiji.css.web.administration.refund;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import cn.com.taiji.common.manager.JsonManagerException;
import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.common.manager.net.http.HttpMimeResponseHelper;
import cn.com.taiji.common.manager.net.http.ServiceHandleException;
import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.css.entity.User;
import cn.com.taiji.css.manager.LoginHelper;
import cn.com.taiji.css.manager.customerservice.finance.CardRefundAccountBookManager;
import cn.com.taiji.css.model.administration.refund.CardRefundAccountBookPageRequest;
import cn.com.taiji.css.web.MyLogController;
import cn.com.taiji.qtk.entity.CardRefundAccountBookDetail;
import cn.com.taiji.qtk.repo.jpa.AgencyRepo;

@Controller
@RequestMapping("/administration/refundbook/refundbookmanager")
public class CardRefundAccountBookController extends MyLogController {

	@Autowired
	private CardRefundAccountBookManager cardRefundAccountBookManager;

	@Autowired
	private AgencyRepo agencyRepo;

	private final String prefix = "administration/refundbook/refundbookmanager/";

	@RequestMapping(value = "/manage", method = RequestMethod.GET)
	public String manageGet(
			@ModelAttribute("queryModel") CardRefundAccountBookPageRequest cardRefundAccountBookPageRequest,
			Model model) {
		model.addAttribute("agencyList", agencyRepo.findAll());
		return prefix + "manage";
	}

	@RequestMapping(value = "/manage", method = RequestMethod.POST)
	public String managePost(@ModelAttribute("queryModel") CardRefundAccountBookPageRequest queryModel, Model model) {
		Pagination pagn = cardRefundAccountBookManager.pageQuery(queryModel);
		model.addAttribute("pagn", pagn);
		return prefix + "queryResult";
	}

	@RequestMapping(value = "/file", method = RequestMethod.GET)
	public String setupFile(@ModelAttribute("pageModel") User user, HttpServletRequest request, Model model) {
		return prefix + "importExcel";
	}

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public String setupEdit(@PathVariable("id") String id, HttpServletRequest request, Model model)
			throws ServiceHandleException, IOException {
		model.addAttribute("pageModel", cardRefundAccountBookManager.findById(id));
		return prefix + "edit";
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String processEdit(@Valid @ModelAttribute("pageModel") CardRefundAccountBookDetail detail,
			HttpServletRequest request, Model model, HttpServletResponse response)
			throws JsonManagerException, ManagerException {
		User loginUser = LoginHelper.getLoginUser(request);
		CardRefundAccountBookDetail updateData = cardRefundAccountBookManager.updateData(detail,loginUser);
		addSuccess(response, "修改成功");
		model.addAttribute("vo", updateData);
		return prefix + "result";

	}

	@RequestMapping(value = "/improtExcel", method = RequestMethod.POST)
	public String improtExcel(HttpServletRequest request, @RequestParam("file") MultipartFile file,@ModelAttribute("queryModel") CardRefundAccountBookPageRequest queryModel,
			HttpServletResponse response) throws ManagerException {
		User loginUser = LoginHelper.getLoginUser(request);
		// 解析excel数据入库存放服务器
		cardRefundAccountBookManager.uploadExcel(file, loginUser);
		addSuccess(response, "修改成功");
		return prefix + "manage";
	}

	@RequestMapping(value = "/exportExcel1", method = RequestMethod.POST)
	public void exportExcel1(@ModelAttribute("queryModel") CardRefundAccountBookPageRequest queryModel,
			HttpServletResponse response) throws ManagerException {
		cardRefundAccountBookManager.exportExcel(queryModel, response);
	}
	
	@RequestMapping(value = "/exportExcel", method = RequestMethod.POST)
	public void exportExcel(@RequestBody CardRefundAccountBookPageRequest queryModel,
			HttpServletResponse response,HttpServletRequest request) throws ManagerException {
		User user = LoginHelper.getLoginUser(request);
		File export = cardRefundAccountBookManager.getExcelFilePath(queryModel,user);
		try {
			HttpMimeResponseHelper.doDownLoad(request, response, export, export.getName());
		} catch (IOException e) {
			e.printStackTrace();
			throw new ManagerException("下载文件失败",e);
		}
	}
}
