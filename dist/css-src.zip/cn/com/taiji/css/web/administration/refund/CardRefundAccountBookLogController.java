package cn.com.taiji.css.web.administration.refund;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.com.taiji.css.manager.customerservice.finance.CardRefundAccountBookLogManager;
import cn.com.taiji.css.model.administration.refund.CardRefundBookLogPageRequest;
import cn.com.taiji.css.web.MyLogController;
@Controller
@RequestMapping("/administration/refundbook/refundbooklog")
public class CardRefundAccountBookLogController  extends MyLogController{

	private final String prefix = "administration/refundbook/refundbooklog/";
	
	@Autowired
	private CardRefundAccountBookLogManager cardRefundAccountBookLogManager;

	@RequestMapping(value = "/manage", method = RequestMethod.GET)
	public String manageGet(@ModelAttribute("queryModel") CardRefundBookLogPageRequest cardRefundBookLogPageRequest,
			Model model) {
		return prefix + "manage";
	}

	@RequestMapping(value = "/manage", method = RequestMethod.POST)
	public String managePost(@Valid @ModelAttribute("queryModel") CardRefundBookLogPageRequest cardRefundBookLogPageRequest,
			Model model) {

		model.addAttribute("pagn", cardRefundAccountBookLogManager.pageQuery(cardRefundBookLogPageRequest));
		return prefix + "queryResult";
	}
	
	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public String view(@PathVariable("id") String id, HttpServletRequest request,Model model)
	{
		model.addAttribute("pageModel", cardRefundAccountBookLogManager.findById(id));
		return prefix + "view";
	}

	
	
	
}
