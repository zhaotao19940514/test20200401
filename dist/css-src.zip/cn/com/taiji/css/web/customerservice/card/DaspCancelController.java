package cn.com.taiji.css.web.customerservice.card;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.common.manager.net.http.HttpMimeResponseHelper;
import cn.com.taiji.css.entity.dict.CssServiceLogType;
import cn.com.taiji.css.manager.LoginHelper;
import cn.com.taiji.css.manager.customerservice.card.CancelManager;
import cn.com.taiji.css.model.customerservice.card.CancelRequest;
import cn.com.taiji.css.web.MyLogController;
import cn.com.taiji.dsi.model.comm.protocol.maintenance.DaspIssOrderLogOffResponse;
import cn.com.taiji.qtk.entity.VehicleInfo;
import cn.com.taiji.qtk.entity.dict.VehiclePlateColorType;
import cn.com.taiji.qtk.repo.jpa.VehicleInfoRepo;

@Controller
@RequestMapping("/customerservice/card/daspCancel")
public class DaspCancelController extends MyLogController{
private final String prefix = "customerservice/card/daspCancel/";
	
	@Autowired
	private CancelManager cancelManager;
//	@Autowired
//	private AccountCardBalanceOperateRepo accountCardBalanceOperateRepo;
	@Autowired
	private VehicleInfoRepo vehicleInfoRepo;

	@RequestMapping(value = "/manage", method = RequestMethod.GET)
	public String manageGet(@ModelAttribute("queryModel") CancelRequest queryModel, Model model)
	{
		model.addAttribute("vehiclePlateColorType", VehiclePlateColorType.values());
		return prefix+"manage";
	}

//	@RequestMapping(value = "/manage", method = RequestMethod.POST)
//	public String managePost(@ModelAttribute("queryModel") CancelRequest queryModel, Model model, HttpServletRequest request) throws ManagerException
//	{
//		
//		LargePagination<CardInfo> pagn = cancelManager.queryPage(queryModel,LoginHelper.getLoginUser(request));
//		model.addAttribute("vehiclePlateColorType", VehiclePlateColorType.values());
//		model.addAttribute("CustomerIDType",CustomerIDType.values());
//		model.addAttribute("CardUploadStatus",CardUploadStatus.values());
//		model.addAttribute("pagn", pagn);
//		if(LoginHelper.getLoginUser(request).getRole().getName().equals("开发测试")) {
//			model.addAttribute("forceFlag",1);
//		}
//		
//		return prefix+"queryResult";
//	}
	
	/**
	 * 部平台卡注销
	 * @param cardId
	 * @param request
	 * @param model
	 * @throws IOException 
	 */
	@RequestMapping(value = "/daspCancel", method = RequestMethod.POST)
	public void daspCancel(@ModelAttribute("queryModel") CancelRequest queryModel, HttpServletResponse response,HttpServletRequest request, Model model) throws IOException
	{
		DaspIssOrderLogOffResponse cancelRes = null;
		VehicleInfo vehicleInfo = vehicleInfoRepo
				.findByVehicleId(queryModel.getVehicleId() + "_" + queryModel.getVehicleColor());
		
		try {
			cancelRes = cancelManager.daspCancel(vehicleInfo, LoginHelper.getLoginUser(request));
			super.doAddLog(request, CssServiceLogType.CUSTOMERSERVICE_CARD_DASP, vehicleInfo);
		} catch (ManagerException e) {
			e.printStackTrace();
			cancelRes = new DaspIssOrderLogOffResponse();
			cancelRes.setStatus(2);
			cancelRes.setMessage(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			cancelRes = new DaspIssOrderLogOffResponse();
			cancelRes.setStatus(2);
			cancelRes.setMessage("未知异常,请联系管理员");
		}
		finally {
			HttpMimeResponseHelper.responseJson(cancelRes.toJson(), response);
		}
		
		
		
	}
}
