package cn.com.taiji.css.web.query;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.css.manager.query.agency.AgencyCardBlackReasonManager;
import cn.com.taiji.css.model.query.AgencyCardBlackReasonRequest;
import cn.com.taiji.css.web.BaseLogController;

@Controller
@RequestMapping("/query/agencyCardBlackReason")
public class AgencyCardBlackReasonController extends BaseLogController {
	private final String prefix = "query/agencyCardBlackReason/";

	@Autowired
	private AgencyCardBlackReasonManager manage;

	@RequestMapping(value = "/manage", method = RequestMethod.GET)
	public String manageGet(@ModelAttribute("queryModel") AgencyCardBlackReasonRequest req, Model model,
			HttpServletRequest request) {
		return prefix + "manage";
	}

	@RequestMapping(value = "/manage", method = RequestMethod.POST)
	public String managePost(@Valid @ModelAttribute("queryModel") AgencyCardBlackReasonRequest req, HttpServletRequest request,
			Model model) throws ManagerException {
		req.setOrgCode("gh_fh_query_blacklist");
		String result = manage.cardBlackReasonQuery(req);
		model.addAttribute("result", result);
		return prefix + "queryResult";
	}
}
