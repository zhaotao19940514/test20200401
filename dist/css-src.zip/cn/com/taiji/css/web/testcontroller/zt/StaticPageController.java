/**
 * @Title RechargeController.java
 * @Package cn.com.taiji.css.web.customerservice.finance
 * @Description TODO
 * @author yaonanlin
 * @date 2018年6月25日 下午5:14:54
 * @version V1.0
 */
package cn.com.taiji.css.web.testcontroller.zt;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.com.taiji.css.model.customerservice.card.CancelRefundRequest;
import cn.com.taiji.css.web.MyLogController;

@Controller
@RequestMapping("/static/page")
public class StaticPageController extends MyLogController {
	private final String prefix = "testjsp/zt/";
	

	@RequestMapping(value = "/finalbusinessmanage", method = RequestMethod.GET)
	public String manageGet(@ModelAttribute("queryModel") CancelRefundRequest queryModel, Model model)
	{
		return prefix+"finalbusinessmanage";
	}
	@RequestMapping(value = "/logisticsdealmanage", method = RequestMethod.GET)
	public String manageGet1(@ModelAttribute("queryModel") CancelRefundRequest queryModel, Model model)
	{
		return prefix+"logisticsdealmanage";
	}
	@RequestMapping(value = "/regionforgetcardmanage", method = RequestMethod.GET)
	public String manageGet2(@ModelAttribute("queryModel") CancelRefundRequest queryModel, Model model)
	{
		return prefix+"regionforgetcardmanage";
	}
	@RequestMapping(value = "/tuijianpersionmanage", method = RequestMethod.GET)
	public String manageGet3(@ModelAttribute("queryModel") CancelRefundRequest queryModel, Model model)
	{
		return prefix+"tuijianpersionmanage";
	}
	@RequestMapping(value = "/onlinecentermanage", method = RequestMethod.GET)
	public String manageGet4(@ModelAttribute("queryModel") CancelRefundRequest queryModel, Model model)
	{
		return prefix+"onlinecentermanage";
	}
	@RequestMapping(value = "/regioncentermanage", method = RequestMethod.GET)
	public String manageGet5(@ModelAttribute("queryModel") CancelRefundRequest queryModel, Model model)
	{
		return prefix+"regioncentermanage";
	}
	@RequestMapping(value = "/provincecentermanage", method = RequestMethod.GET)
	public String manageGet6(@ModelAttribute("queryModel") CancelRefundRequest queryModel, Model model)
	{
		return prefix+"provincecentermanage";
	}
	@RequestMapping(value = "/salesmanmanage", method = RequestMethod.GET)
	public String manageGet7(@ModelAttribute("queryModel") CancelRefundRequest queryModel, Model model)
	{
		return prefix+"salesmanmanage";
	}
	@RequestMapping(value = "/governcardobumanage", method = RequestMethod.GET)
	public String manageGet8(@ModelAttribute("queryModel") CancelRefundRequest queryModel, Model model)
	{
		return prefix+"governcardobumanage";
	}
	@RequestMapping(value = "/onlineoutinmanage", method = RequestMethod.GET)
	public String manageGet9(@ModelAttribute("queryModel") CancelRefundRequest queryModel, Model model)
	{
		return prefix+"onlineoutinmanage";
	}
	@RequestMapping(value = "/regionoutinmanage", method = RequestMethod.GET)
	public String manageGet10(@ModelAttribute("queryModel") CancelRefundRequest queryModel, Model model)
	{
		return prefix+"regionoutinmanage";
	}
	@RequestMapping(value = "/businessofficeoutinmanage", method = RequestMethod.GET)
	public String manageGet11(@ModelAttribute("queryModel") CancelRefundRequest queryModel, Model model)
	{
		return prefix+"businessofficeoutinmanage";
	}
	@RequestMapping(value = "/businessofficeoutindaymanage", method = RequestMethod.GET)
	public String manageGet12(@ModelAttribute("queryModel") CancelRefundRequest queryModel, Model model)
	{
		return prefix+"businessofficeoutindaymanage";
	}
	@RequestMapping(value = "/regionoutindaymanage", method = RequestMethod.GET)
	public String manageGet13(@ModelAttribute("queryModel") CancelRefundRequest queryModel, Model model)
	{
		return prefix+"regionoutindaymanage";
	}
	@RequestMapping(value = "/onlineoutindaymanage", method = RequestMethod.GET)
	public String manageGet14(@ModelAttribute("queryModel") CancelRefundRequest queryModel, Model model)
	{
		return prefix+"onlineoutindaymanage";
	}
	@RequestMapping(value = "/outinmanage", method = RequestMethod.GET)
	public String manageGet15(@ModelAttribute("queryModel") CancelRefundRequest queryModel, Model model)
	{
		return prefix+"outinmanage";
	}
}


